INSERT INTO cartoes_credito (id,nome_titular,cpf,numero_cartao,data_validade,banco_associado,nome_cartao,limite_credito) VALUES (1,'RAMON BARBOSA SOUZA',85778905548,0204,'2029-02',2,'Nubank',5900.00);
INSERT INTO cartoes_credito (id,nome_titular,cpf,numero_cartao,data_validade,banco_associado,nome_cartao,limite_credito) VALUES (2,'RAMON BARBOSA',85778905548,2750,'2024-12',1,'Brasil',1560.00);
INSERT INTO cartoes_credito (id,nome_titular,cpf,numero_cartao,data_validade,banco_associado,nome_cartao,limite_credito) VALUES (3,'RAMON BARBOSA SOUZA',85778905548,6346,'2024-12',3,'Bradesco',1000.00);
INSERT INTO cartoes_credito (id,nome_titular,cpf,numero_cartao,data_validade,banco_associado,nome_cartao,limite_credito) VALUES (4,'RAMON B. SOUZA',85778905548,4312,'2030-12',4,'CAIXA',500.00);
