INSERT INTO despesa_cartao (id,id_cartao_credito,anoMes,cpf,valor_total) VALUES (2,2,202401,85778905548,147.73);
INSERT INTO despesa_cartao (id,id_cartao_credito,anoMes,cpf,valor_total) VALUES (1,1,202401,85778905548,284.45);
INSERT INTO despesa_cartao (id,id_cartao_credito,anoMes,cpf,valor_total) VALUES (3,3,202401,85778905548,147.16);
INSERT INTO despesa_cartao (id,id_cartao_credito,anoMes,cpf,valor_total) VALUES (4,4,202401,85778905548,180.00);
