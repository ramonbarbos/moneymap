INSERT INTO item_despesa (id_item,despesa_id,dt_despesa,evento_id,descricao,valor,saldo,fl_situacao) VALUES (5,1,'2024-01-15',29,'Fatura FIES',180.00,313.98,0);
INSERT INTO item_despesa (id_item,despesa_id,dt_despesa,evento_id,descricao,valor,saldo,fl_situacao) VALUES (4,1,'2024-01-08',28,'Fatura Iphone',147.16,493.98,0);
INSERT INTO item_despesa (id_item,despesa_id,dt_despesa,evento_id,descricao,valor,saldo,fl_situacao) VALUES (3,1,'2024-01-08',27,'Fatura Iphone',147.73,641.14,0);
INSERT INTO item_despesa (id_item,despesa_id,dt_despesa,evento_id,descricao,valor,saldo,fl_situacao) VALUES (2,1,'2024-01-08',31,'Aluguel',650.00,788.87,0);
INSERT INTO item_despesa (id_item,despesa_id,dt_despesa,evento_id,descricao,valor,saldo,fl_situacao) VALUES (1,1,'2024-01-08',17,'Fatura Gerais',284.45,1438.87,0);
