INSERT INTO system_user_unit (id,system_user_id,system_unit_id) VALUES (12,1,2);
INSERT INTO system_user_unit (id,system_user_id,system_unit_id) VALUES (11,1,1);
INSERT INTO system_user_unit (id,system_user_id,system_unit_id) VALUES (10,2,2);
INSERT INTO system_user_unit (id,system_user_id,system_unit_id) VALUES (9,2,1);
INSERT INTO system_user_unit (id,system_user_id,system_unit_id) VALUES (13,3,1);
