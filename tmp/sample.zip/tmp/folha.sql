INSERT INTO folha (id,tp_folha,anoMes,cpf,vl_salario,vl_desconto) VALUES (1,1,202312,85778905548,2189.27,0.00);
INSERT INTO folha (id,tp_folha,anoMes,cpf,vl_salario,vl_desconto) VALUES (2,2,202312,85778905548,638.00,0.00);
INSERT INTO folha (id,tp_folha,anoMes,cpf,vl_salario,vl_desconto) VALUES (3,1,202401,85778905548,1723.32,740.00);
