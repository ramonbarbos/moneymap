INSERT INTO item_despesa_cartao (id_item,despesa_cartao_id,evento_id,dt_despesa,descricao,parcela,valor,fl_situacao) VALUES (11,1,21,'','UBER+99',0,23.75,0);
INSERT INTO item_despesa_cartao (id_item,despesa_cartao_id,evento_id,dt_despesa,descricao,parcela,valor,fl_situacao) VALUES (10,1,33,'','Google',0,13.90,0);
INSERT INTO item_despesa_cartao (id_item,despesa_cartao_id,evento_id,dt_despesa,descricao,parcela,valor,fl_situacao) VALUES (9,1,21,'','Aguia Branca',0,88.65,0);
INSERT INTO item_despesa_cartao (id_item,despesa_cartao_id,evento_id,dt_despesa,descricao,parcela,valor,fl_situacao) VALUES (8,3,35,'2024-01-08','Iphone',0,147.16,0);
INSERT INTO item_despesa_cartao (id_item,despesa_cartao_id,evento_id,dt_despesa,descricao,parcela,valor,fl_situacao) VALUES (7,2,34,'2024-01-08','IPHONE',0,147.73,0);
INSERT INTO item_despesa_cartao (id_item,despesa_cartao_id,evento_id,dt_despesa,descricao,parcela,valor,fl_situacao) VALUES (12,1,36,'','Amazon - Amigo Secreto',0,94.99,0);
INSERT INTO item_despesa_cartao (id_item,despesa_cartao_id,evento_id,dt_despesa,descricao,parcela,valor,fl_situacao) VALUES (13,1,36,'','Filtro de Linha',0,63.16,0);
INSERT INTO item_despesa_cartao (id_item,despesa_cartao_id,evento_id,dt_despesa,descricao,parcela,valor,fl_situacao) VALUES (14,4,29,'2024-01-15','FIES',0,180.00,0);
