INSERT INTO ano_mes (id,descricao) VALUES (5,202401);
INSERT INTO ano_mes (id,descricao) VALUES (4,202312);
INSERT INTO ano_mes (id,descricao) VALUES (6,202402);
