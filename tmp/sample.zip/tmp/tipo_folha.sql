INSERT INTO tipo_folha (id,descricao) VALUES (1,'Mensal');
INSERT INTO tipo_folha (id,descricao) VALUES (2,'Extra 01');
