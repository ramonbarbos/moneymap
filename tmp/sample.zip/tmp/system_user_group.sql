INSERT INTO system_user_group (id,system_user_id,system_group_id) VALUES (10,1,2);
INSERT INTO system_user_group (id,system_user_id,system_group_id) VALUES (8,2,2);
INSERT INTO system_user_group (id,system_user_id,system_group_id) VALUES (9,1,1);
INSERT INTO system_user_group (id,system_user_id,system_group_id) VALUES (11,3,2);
