INSERT INTO system_unit (id,name,connection_name) VALUES (1,'Unit A','unit_a');
INSERT INTO system_unit (id,name,connection_name) VALUES (2,'Unit B','unit_b');
