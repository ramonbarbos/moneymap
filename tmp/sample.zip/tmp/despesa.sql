INSERT INTO despesa (id,folha_id,tp_folha,anoMes,cpf,vl_despesa,saldo,situacao) VALUES (1,3,1,202401,85778905548,1409.34,313.98,0);
