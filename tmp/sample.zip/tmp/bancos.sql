INSERT INTO bancos (id,nome,codigo_banco,site,telefone) VALUES (1,'Brasil',001,'','');
INSERT INTO bancos (id,nome,codigo_banco,site,telefone) VALUES (2,'Nubank',260,'','');
INSERT INTO bancos (id,nome,codigo_banco,site,telefone) VALUES (3,'Bradesco',247,'','');
INSERT INTO bancos (id,nome,codigo_banco,site,telefone) VALUES (4,'CAIXA',104,'','');
